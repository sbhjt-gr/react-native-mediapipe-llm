import type { MemoryConfiguration } from './NativeMediapipeLlm';
declare const MediaPipeLlm: any;
export { MemoryConfiguration };
export default MediaPipeLlm;
//# sourceMappingURL=MediaPipeLlm.d.ts.map