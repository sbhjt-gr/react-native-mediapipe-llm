import type { TurboModule } from 'react-native';
export interface MemoryConfiguration {
    totalRamGB: number;
    totalRamMB: number;
    availableRamMB: number;
    currentHeapMB: number;
    potentialHeapMB: number;
    deviceCategory: 'flagship_ultra' | 'flagship_pro' | 'flagship' | 'premium' | 'mid_range' | 'budget_plus' | 'budget';
    isLargeHeapEnabled: boolean;
    maxModelSizeMB: number;
    warningThresholdMB: number;
    recommendation: string;
    potentialAfterOptimization: number;
    recommendations: string[];
    warnings: string[];
    info: string[];
    gradleRecommendations: string[];
    manifestRecommendations: string[];
    memoryStatus: 'excellent' | 'good' | 'moderate' | 'limited';
}
export interface Spec extends TurboModule {
    createModelFromAsset(modelName: string, maxTokens: number, topK: number, temperature: number, randomSeed: number): Promise<number>;
    createModel(modelPath: string, maxTokens: number, topK: number, temperature: number, randomSeed: number): Promise<number>;
    generateResponse(modelHandle: number, requestId: number, prompt: string): Promise<string>;
    releaseModel(modelHandle: number): Promise<void>;
    getMemoryConfiguration(): Promise<MemoryConfiguration>;
    multiply(a: number, b: number): number;
    addListener(eventName: string): void;
    removeListeners(count: number): void;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeMediapipeLlm.d.ts.map