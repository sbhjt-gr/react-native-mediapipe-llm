export declare const MediapipeLlm: any;
export declare function isMediapipeLlmAvailable(): boolean;
export declare function getMediapipeLlmModule(): any;
//# sourceMappingURL=index.d.ts.map