export declare const MediapipeLlm: any;
export declare function isMediapipeLlmAvailable(): boolean;
export declare function getMediapipeLlmModule(): any;
//# sourceMappingURL=simple.d.ts.map