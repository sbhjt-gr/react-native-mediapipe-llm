export declare function getMediapipeLlmModule(): any;
export declare function isMediapipeLlmAvailable(): boolean;
//# sourceMappingURL=NativeModule.d.ts.map